<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

           <h1 class="h1 text-center"><?php echo e(__('Money Transfer')); ?></h1>
            <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form role="form" class="account-detail-form text-center" method="POST" action="<?php echo e(route('bankTransaction.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="amount">
                            <h6>Amount</h6>
                        </label>
                        <input type="text" name="amount" value="<?php echo e(old('amount')); ?>" placeholder="Amount" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="destinationFirstname">
                            <h6>Destination Firstname</h6>
                        </label>
                        <input type="text" name="destinationFirstname" value="<?php echo e(old('destinationFirstname')); ?>" placeholder="Destination Firstname" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="destinationLastname">
                            <h6>Destination Lastname</h6>
                        </label>
                        <input type="text" name="destinationLastname" value="<?php echo e(old('destinationLastname')); ?>" placeholder="Destination Lastname" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="destinationNumber">
                            <h6>Destination Number</h6>
                        </label>
                        <input type="text" name="destinationNumber" value="<?php echo e(old('destinationNumber')); ?>" placeholder="Destination Number" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="paymentNumber">
                            <h6>Payment Number</h6>
                        </label>
                        <input type="text" name="paymentNumber" value="<?php echo e(old('paymentNumber')); ?>" placeholder="Payment Number" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="deposit">
                            <h6>Deposit</h6>
                        </label>
                        <input type="text" name="deposit" value="<?php echo e($card->deposit); ?>" placeholder="Deposit" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="sourceFirstName">
                            <h6>Source FirstName</h6>
                        </label>
                        <input type="text" name="sourceFirstName" value="<?php echo e($card->firstname); ?>" placeholder="Source FirstName" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="sourceLastName">
                            <h6>Source LastName</h6>
                        </label>
                        <input type="text" name="sourceLastName" value="<?php echo e($card->lastname); ?>" placeholder="Source lastName" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="description">
                            <h6>Description</h6>
                        </label>
                        <textarea type="text" name="description" placeholder="Description" required class="form-control"><?php echo e(old('description')); ?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="reasonDescription">
                            <h6>Reason Description</h6>
                        </label>
                        <textarea type="text" name="reasonDescription" placeholder="Reason Description" required class="form-control"><?php echo e(old('reasonDescription')); ?></textarea>
                    </div>
                </div>

                <div class="form-group submit-button">
                    <div class="detail-input">
                        <input type="submit" class="btn btn-primary btn-block shadow-sm" style="margin-top: 20px" value="Transfer">
                    </div>
                </div>

            </form>


    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amir/Desktop/bank/resources/views/moneyTransfer.blade.php ENDPATH**/ ?>