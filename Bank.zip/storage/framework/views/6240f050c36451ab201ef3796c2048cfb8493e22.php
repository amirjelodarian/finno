<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">


           <h1 class="h1 text-center"><?php echo e(__('Enter Account Detail')); ?></h1>
            <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form role="form" class="account-detail-form text-center" method="POST" action="<?php echo e(route('accountDetail.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="detail-input">
                        <label for="firstname">
                            <h6>First Name</h6>
                        </label>
                        <input type="text" name="firstname" value="<?php echo e(old('firstname')); ?>" placeholder="First Name" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="username">
                            <h6>Last Name</h6>
                        </label>
                        <input type="text" name="lastname" value="<?php echo e(old('lastname')); ?>" placeholder="Last Name" required class="form-control">
                     </div>
                </div>

                <div class="form-group deposit-div">
                    <div class="detail-input">
                        <label for="deposit">
                            <h6>Deposit</h6>
                        </label>
                        <input type="text" name="deposit" value="<?php echo e(old('deposit')); ?>" placeholder="123456789" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="cvv2">
                            <h6>CVV2</h6>
                        </label>
                        <input type="text" name="cvv2" value="<?php echo e(old('cvv2')); ?>" placeholder="CVV2" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="month">
                            Month
                        </label>
                        <input type="number" placeholder="12" name="month" value="<?php echo e(old('month')); ?>" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="year">
                            Year
                        </label>
                        <input type="number" placeholder="1400" name="year" value="<?php echo e(old('year')); ?>" class="form-control" required>
                    </div>
                </div>


                <div class="form-group submit-button">
                    <div class="detail-input">
                        <input type="submit" class="btn btn-primary btn-block shadow-sm" value="Save">
                    </div>
                </div>

            </form>


    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amir/Desktop/bank/resources/views/accountDetail.blade.php ENDPATH**/ ?>