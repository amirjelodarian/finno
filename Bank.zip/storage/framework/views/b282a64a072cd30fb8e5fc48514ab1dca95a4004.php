<?php if($errors->count() > 0): ?>
    <div class="account-detail-error" role="alert">
        <h2>Fix Errors</h2>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /home/amir/Desktop/bank/resources/views/layouts/error.blade.php ENDPATH**/ ?>