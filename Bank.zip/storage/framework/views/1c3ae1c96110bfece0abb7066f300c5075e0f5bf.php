<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

           <h1 class="h1 text-center"><?php echo e(__('Transaction Log')); ?></h1>
            <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="account-detail-div text-center">

                <?php $__currentLoopData = $BT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="form-group">
                        <div class="detail-div">

                            <h6><?php echo e($bt->destinationFirstname); ?> <?php echo e($bt->destinationLastname); ?></h6>
                            <p>Amount : <?php echo e($bt->amount); ?></p>
                            <span>Des Num : </span><span><?php echo e($bt->destinationNumber); ?></span><br />
                            <span>Reas Des : </span><span><?php echo e($bt->reasonDescription); ?></span><br />
                            <span>Deposit : </span><span><?php echo e($bt->deposit); ?></span><br />
                            <span>Desc : </span><span><?php echo e($bt->description); ?></span><br />
                            <span>Time : </span><span><?php echo e($bt->created_at); ?></span><br />


                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>



    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amir/Desktop/bank/resources/views/moneyTransactions.blade.php ENDPATH**/ ?>