<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;

class BankTransaction extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function sendFinnReq($request ,$token, $clientId, $trackId)
    {
        $url = "https://apibeta.finnotech.ir/oak/v2/clients/{$clientId}/transferTo?trackId={$trackId}";
        //$url = "http://localhost:8000/oak/v2/clients/{$clientId}/transferTo?trackId={$trackId}";
        $response = Http::withHeaders(
            [
            'Content-Type'  => "application/json",
            'Authorization' => "Bearer {$token}"
            ])->
            post($url ,
            [
                $request->except('_token')
            ]);
        return $response->json();
    }
}
