<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class AccountDetailRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'firstname' => 'required|min:2|max:255',
            'lastname'  => 'required|min:2|max:255',
            'cvv2'      => 'required|between:1000,9999|numeric',
            'deposit'    => 'required|between:100000000,999999999|numeric',
            'month'     => 'required|between:01,12|numeric',
            'year'      => 'required|between:1300,1500|numeric',
        ];
    }

    public function messages()
    {
        return [
          /*  'firstname.min'      => 'Firstname is smaller than 3',
            'firstname.max'      => 'Firstname length is higher than 255',
            'lastname.min'       => 'Lastname is smaller than 3',
            'lastname.max'       => 'Lastname length is higher than 255',
            'cvv2.integer'       => 'Cvv2 must be integer',
            'cvv2.size'          => 'Cvv2 length must be 4',
            'cardNumber.integer' => 'Cart number must be integer',*/
            'deposit.between'    => 'Deposit number is invalid !',
            /*'month.integer'    => 'Month must be integer',
            'month.size'         => 'Month length must be 2',
            'year.integer'       => 'Year must be integer',
            'year.size'          => 'Year length must be 4',*/
        ];
    }

    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'errors' => $validator->errors(),
            ], 422));
    }
}
