<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class BankTransactionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'amount'               => 'required|between:1,999999999|numeric',
            'description'          => 'required|min:2|max:30',
            'destinationFirstname' => 'required|min:2|max:33',
            'destinationLastname'  => 'required|min:2|max:33',
            'destinationNumber'    => 'required|min:9|max:26',
            'paymentNumber'        => 'nullable|max:30',
            'reasonDescription'    => 'max:255',
            'deposit'              => 'between:100000000,999999999|numeric',
            'sourceFirstName'      => 'required|min:2|max:255',
            'sourceLastName'       => 'required|min:2|max:255',
        ];
    }

    public function failedValidation(Validator $validator){
        throw new HttpResponseException(response()->json([
            'errors' => $validator->errors(),
        ], 422));
    }
}
