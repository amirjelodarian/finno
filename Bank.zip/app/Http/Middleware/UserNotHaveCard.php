<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class UserNotHaveCard
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if(!(auth()->user()->accountDetail()->exists()))
        {
            return response()->json(['errors' => 'Add Card !'], Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        return $next($request);
    }
}
