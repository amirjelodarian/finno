<?php



namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if(Gate::allows('UserHaveCard'))
            return view('home');
        else
            return view('accountDetail');

    }

    public function edit()
    {
        if(Gate::allows('UserHaveCard')){
            $card = auth()->user()->accountDetail()->first();
            return view('accountDetailEdit', compact('card'));
        }
        else
            return view('home');

    }

    public function moneyTransferShow(){
        if(Gate::allows('UserHaveCard')){
            $card = auth()->user()->accountDetail()->first();
            return view('moneyTransfer', compact('card'));
        }
        else
            return view('home');
    }
}
