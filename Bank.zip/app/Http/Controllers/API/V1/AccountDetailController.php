<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\AccountDetailRequest;
use App\Models\AccountDetail;
use App\Models\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class AccountDetailController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('UserHaveCard')->only(['store', 'create']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        return 'Account Detail Index , I want at soon show user account detail  ';
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('accountDetail');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AccountDetailRequest $request)
    {

        // check card if exists not create new card !
        if( ! Gate::allows('UserHaveCard'))
        {
            auth()->user()->accountDetail()->create($request->all());
            return response()->json(['message' => 'create'], Response::HTTP_CREATED);
        }
        return response()->json(['errors' => 'Card exists !'], Response::HTTP_UNPROCESSABLE_ENTITY);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AccountDetailRequest $request, $id)
    {
        if(auth()->user()->accountDetail()->whereId($id)->exists()){
            auth()->user()->accountDetail()->whereId($id)->update($request->except(['_token', '_method']));
            return response()->json(['message' => 'Edited'], Response::HTTP_OK);
        }
        return response()->json(['errors' => 'Card owner error !'], Response::HTTP_UNAUTHORIZED);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
