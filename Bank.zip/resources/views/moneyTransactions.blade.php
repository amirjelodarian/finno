@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">

           <h1 class="h1 text-center">{{ __('Transaction Log') }}</h1>
            @include('layouts.error')
            <div class="account-detail-div text-center">

                @foreach ($BT as $bt)

                    <div class="form-group">
                        <div class="detail-div">

                            <h6>{{ $bt->destinationFirstname }} {{ $bt->destinationLastname }}</h6>
                            <p>Amount : {{ $bt->amount }}</p>
                            <span>Des Num : </span><span>{{ $bt->destinationNumber }}</span><br />
                            <span>Reas Des : </span><span>{{ $bt->reasonDescription }}</span><br />
                            <span>Deposit : </span><span>{{ $bt->deposit }}</span><br />
                            <span>Desc : </span><span>{{ $bt->description }}</span><br />
                            <span>Time : </span><span>{{ $bt->created_at }}</span><br />


                        </div>
                    </div>

                @endforeach



            </div>



    </div>

</div>
@endsection
