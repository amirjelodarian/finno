@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">


           <h1 class="h1 text-center">{{ __('Edit') }}</h1>
            @include('layouts.error')
            <form role="form" class="account-detail-form text-center" method="POST" action="{{ route('accountDetail.update', $card->id) }}">
                @csrf
                @method('PATCH')
                <div class="form-group">
                    <div class="detail-input">
                        <label for="firstname">
                            <h6>First Name</h6>
                        </label>
                        <input type="text" name="firstname" value="{{ $card->firstname }}" placeholder="First Name" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="username">
                            <h6>Last Name</h6>
                        </label>
                        <input type="text" name="lastname" value="{{ $card->lastname }}" placeholder="Last Name" required class="form-control">
                     </div>
                </div>

                <div class="form-group deposit-div">
                    <div class="detail-input">
                        <label for="deposit">
                            <h6>Deposit</h6>
                        </label>
                        <input type="text" name="deposit" value="{{ $card->deposit }}" placeholder="Deposit" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="cvv2">
                            <h6>CVV2</h6>
                        </label>
                        <input type="text" name="cvv2" value="{{ $card->cvv2 }}" placeholder="CVV2" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="month">
                            Month
                        </label>
                        <input type="number" placeholder="12" name="month" value="{{ $card->month }}" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="year">
                            Year
                        </label>
                        <input type="number" placeholder="1400" name="year" value="{{ $card->year }}" class="form-control" required>
                    </div>
                </div>



                <div class="form-group submit-button">
                    <div class="detail-input">
                        <input type="submit" class="btn btn-primary btn-block shadow-sm" value="Edit">
                    </div>
                </div>

            </form>


    </div>

</div>
@endsection
