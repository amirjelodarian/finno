@if ($errors->count() > 0)
    <div class="account-detail-error" role="alert">
        <h2>Fix Errors</h2>
        @foreach ($errors->all() as $error)
            <p>{{ $error }}</p>
        @endforeach
    </div>
@endif
