@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">

           <h1 class="h1 text-center">{{ __('Money Transfer') }}</h1>
            @include('layouts.error')
            <form role="form" class="account-detail-form text-center" method="POST" action="{{ route('bankTransaction.store') }}">
                @csrf

                <div class="form-group">
                    <div class="detail-input">
                        <label for="amount">
                            <h6>Amount</h6>
                        </label>
                        <input type="text" name="amount" value="{{ old('amount') }}" placeholder="Amount" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="destinationFirstname">
                            <h6>Destination Firstname</h6>
                        </label>
                        <input type="text" name="destinationFirstname" value="{{ old('destinationFirstname') }}" placeholder="Destination Firstname" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="destinationLastname">
                            <h6>Destination Lastname</h6>
                        </label>
                        <input type="text" name="destinationLastname" value="{{ old('destinationLastname') }}" placeholder="Destination Lastname" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="destinationNumber">
                            <h6>Destination Number</h6>
                        </label>
                        <input type="text" name="destinationNumber" value="{{ old('destinationNumber') }}" placeholder="Destination Number" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="paymentNumber">
                            <h6>Payment Number</h6>
                        </label>
                        <input type="text" name="paymentNumber" value="{{ old('paymentNumber') }}" placeholder="Payment Number" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="deposit">
                            <h6>Deposit</h6>
                        </label>
                        <input type="text" name="deposit" value="{{ $card->deposit }}" placeholder="Deposit" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="sourceFirstName">
                            <h6>Source FirstName</h6>
                        </label>
                        <input type="text" name="sourceFirstName" value="{{ $card->firstname }}" placeholder="Source FirstName" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="sourceLastName">
                            <h6>Source LastName</h6>
                        </label>
                        <input type="text" name="sourceLastName" value="{{ $card->lastname }}" placeholder="Source lastName" required class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="description">
                            <h6>Description</h6>
                        </label>
                        <textarea type="text" name="description" placeholder="Description" required class="form-control">{{ old('description') }}</textarea>
                    </div>
                </div>

                <div class="form-group">
                    <div class="detail-input">
                        <label for="reasonDescription">
                            <h6>Reason Description</h6>
                        </label>
                        <textarea type="text" name="reasonDescription" placeholder="Reason Description" required class="form-control">{{ old('reasonDescription') }}</textarea>
                    </div>
                </div>

                <div class="form-group submit-button">
                    <div class="detail-input">
                        <input type="submit" class="btn btn-primary btn-block shadow-sm" style="margin-top: 20px" value="Transfer">
                    </div>
                </div>

            </form>


    </div>

</div>
@endsection
