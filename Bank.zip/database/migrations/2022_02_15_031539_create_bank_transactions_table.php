<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBankTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bank_transactions', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id')->unsigned();
            $table->string('amount', 255);
            $table->string('description', 30);
            $table->string('destinationFirstname', 33);
            $table->string('destinationLastname', 33);
            $table->string('destinationNumber', 26);
            $table->string('paymentNumber', 30)->nullable();
            $table->string('reasonDescription', 255)->nullable();
            $table->string('deposit', 9)->nullable();
            $table->string('sourceFirstName', 255)->nullable();
            $table->string('sourceLastName', 255)->nullable();
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete()->cascadeOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bank_transactions');
    }
}
